#include <X360Arduino.h>

// Slowly move the left stick in four directions, then return to center.
void setup() {
  Serial.begin(115200);
  delay(800);
  X360Arduino.begin();
}

void loop() {
  X360Arduino.leftStick(0.0f, 1.0f);   // up
  delay(500);
  X360Arduino.leftStick(1.0f, 0.0f);   // right
  delay(500);
  X360Arduino.leftStick(0.0f, -1.0f);  // down
  delay(500);
  X360Arduino.leftStick(-1.0f, 0.0f);  // left
  delay(500);
  X360Arduino.leftStick(0.0f, 0.0f);   // center
  delay(1000);
}
