#include <X360Arduino.h>

// Tap D-pad Right for 150 ms every 2 seconds.
// Change PRESS_MS and INTERVAL_MS to adjust the timing.
constexpr uint32_t PRESS_MS = 150;
constexpr uint32_t INTERVAL_MS = 2000;
uint32_t lastTap = 0;
uint32_t pressedAt = 0;
bool pressed = false;

void setup() {
  Serial.begin(115200);
  delay(800);
  Serial.println("Starting X360Arduino...");
  if (!X360Arduino.begin()) {
    Serial.println("USB startup failed. Check board and USB-OTG/TinyUSB settings.");
  }
}

void loop() {
  const uint32_t now = millis();
  if (!pressed && now - lastTap >= INTERVAL_MS) {
    X360Arduino.dpadRight(true);
    pressed = true;
    pressedAt = now;
    lastTap = now;
    Serial.println("D-pad Right pressed");
  }
  if (pressed && now - pressedAt >= PRESS_MS) {
    X360Arduino.dpadRight(false);
    pressed = false;
    Serial.println("D-pad Right released");
  }
  delay(1);
}
