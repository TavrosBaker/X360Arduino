#pragma once
#include <Arduino.h>
#include <stdint.h>

// Standard Xbox 360 controller controls exposed by X360Arduino.
// Button methods take true = held/pressed and false = released.
enum class X360Button : uint8_t {
  DpadUp, DpadDown, DpadLeft, DpadRight,
  Start, Back, LeftStickClick, RightStickClick,
  LeftBumper, RightBumper, Guide,
  A, B, X, Y
};

class X360ArduinoClass {
public:
  // Starts the ESP32-S3 USB device. Select USB-OTG (TinyUSB) in Arduino Tools.
  bool begin();
  // True after TinyUSB reports the device mounted and the controller IN endpoint opened.
  bool ready() const;
  // Alias for ready(), provided for readability in sketches.
  bool connected() const { return ready(); }

  // Generic button interface; see X360Button above.
  bool button(X360Button which, bool down);

  // D-pad
  bool dpadUp(bool down); bool dpadDown(bool down);
  bool dpadLeft(bool down); bool dpadRight(bool down);
  // Menu / system buttons
  bool start(bool down); bool back(bool down); bool guide(bool down);
  // Stick clicks (L3 / R3)
  bool leftStickClick(bool down); bool rightStickClick(bool down);
  // Shoulder buttons (LB / RB)
  bool leftBumper(bool down); bool rightBumper(bool down);
  // Face buttons
  bool a(bool down); bool b(bool down); bool x(bool down); bool y(bool down);

  // Triggers: 0.0 = released, 1.0 = fully pressed, values between are analog.
  bool leftTrigger(float value);
  bool rightTrigger(float value);

  // Sticks: each axis ranges from -1.0 to +1.0.
  // X: -1 left, 0 centered, +1 right. Y: -1 down, 0 centered, +1 up.
  bool leftStick(float x, float y);
  bool rightStick(float x, float y);

  // Sends the current stored state again. Useful if USB was not ready earlier.
  bool send();
  // Releases all buttons and centers sticks/releases triggers.
  bool releaseAll();
  // Text describing the latest XSM3 authentication phase; not proof of Xbox acceptance.
  const char *authenticationStatus() const;

private:
  uint32_t buttons_ = 0;
  float lx_=0, ly_=0, rx_=0, ry_=0, lt_=0, rt_=0;
  bool started_ = false;
  bool setButton(uint32_t mask, bool down);
};

// Global controller object used by sketches: X360Arduino.begin(), etc.
extern X360ArduinoClass X360Arduino;
