# Changelog

## 1.0.0
- Finalized package name as X360Arduino.
- Renamed public header and global object to `X360Arduino.h` / `X360Arduino`.
- Documented all exposed standard Xbox 360 controller buttons, triggers, and analog stick axes.
- Added generic `button(X360Button, bool)` API and `connected()` readiness alias.
- Added examples for D-pad timing, button/trigger, and analog sticks.
- Included full README API reference and troubleshooting guide.

## Based on
- XBridge360Arduino 0.1.1 Arduino-ESP32 port and bundled XSM3/ExCrypt sources.
