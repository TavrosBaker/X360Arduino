#include <X360Arduino.h>

// Regression test: tap D-pad Right for 150 ms, then repeat every 2 seconds.
// Open Serial Monitor at 115200 baud to view status messages.
constexpr uint32_t PRESS_MS = 150;
constexpr uint32_t INTERVAL_MS = 2000;

uint32_t lastTap = 0;
uint32_t pressedAt = 0;
bool pressed = false;

void setup() {
  Serial.begin(115200);
  delay(800);
  Serial.println("X360Arduino D-pad Right regression test");
  Serial.println("Expected: Right press for 150 ms, repeat every 2000 ms.");

  if (!X360Arduino.begin()) {
    Serial.println("WARNING: begin() reported startup failure. Check ESP32-S3 USB settings.");
  } else {
    Serial.println("begin() returned true.");
  }
}

void loop() {
  const uint32_t now = millis();

  if (!pressed && now - lastTap >= INTERVAL_MS) {
    if (X360Arduino.dpadRight(true)) {
      Serial.println("D-pad RIGHT pressed");
    } else {
      Serial.println("D-pad RIGHT press report was not queued");
    }
    pressed = true;
    pressedAt = now;
    lastTap = now;
  }

  if (pressed && now - pressedAt >= PRESS_MS) {
    if (X360Arduino.dpadRight(false)) {
      Serial.println("D-pad RIGHT released");
    } else {
      Serial.println("D-pad RIGHT release report was not queued");
    }
    pressed = false;
  }

  delay(1);
}
